import * as PIXI from "/js/pixi.mjs";
import { createCamera } from "./camera.js";
import { initRenderer, getApp, getLayers, redrawAll, setFleetTarget, clearFleetTargets, lerpFleetVisuals, bezierControlPoint, bezierPoint } from "./renderer.js";
import { initNameplates, addNameplate, updateAllNameplates } from "./nameplates.js";
import { initMenu, showMenu, hideMenu } from "./contextMenu.js";
import { setupInput } from "./input.js";
import {
  createBeltParticles,
  createRingParticles,
  updateBeltAnimations,
} from "./particles.js";

export let camera;

let app;
let ws;
let playerId = null;
let fleetId = null;

const bodies = {};
const bodyList = [];
let centerX = 0;
let centerY = 0;
let roomSize = 0;

const currentPositions = {};
let fleetPositions = {};
let currentMovements = [];

let beltParticlesInitialized = false;
let ringContainer = null;

let lastSimulatedTime = 0;
let lastWallTime = 0;
const fleetExtra = {};

window.__bodies = bodyList;
window.__currentPositions = currentPositions;
window.__centerX = centerX;
window.__centerY = centerY;

const SESSION_KEY = "zeus_session_id";

const loginOverlay = document.getElementById("loginOverlay");
const loginSelect = document.getElementById("startBody");
const loginBtn = document.getElementById("btnStart");
const loginTitle = document.querySelector("#loginBox h1");
const loginLabel = document.querySelector("#loginBox label");
const loginHint = document.querySelector("#loginBox .hint");

function getOrCreateSessionId() {
  try {
    let id = localStorage.getItem(SESSION_KEY);
    if (!id) {
      id = "session-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
      localStorage.setItem(SESSION_KEY, id);
    }
    return id;
  } catch (_) {
    return "session-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
  }
}

function hideLogin() {
  loginOverlay.style.display = "none";
}

function connect(sessionId, startingBody) {
  ws = new WebSocket("ws://" + location.hostname + ":3001");

  ws.onopen = () => {
    ws.send(JSON.stringify({
      type: "COMMAND",
      action: "HELLO",
      payload: { sessionId, startingBody },
    }));
  };

  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    handleMessage(msg);
  };

  ws.onclose = () => {
    setTimeout(() => connect(sessionId, startingBody), 2000);
  };
}

function handleMessage(msg) {
  switch (msg.type) {
    case "WELCOME":
      playerId = msg.playerId;
      fleetId = msg.playerId;
      hideLogin();
      break;

    case "SYSTEM_DATA":
      initSystem(msg.payload.system);
      break;

    case "FLEET_DATA":
      fleetId = msg.payload.fleetId;
      break;

    case "MOVE_STARTED":
      break;

    case "STATE_UPDATE":
      applyStateUpdate(msg.payload);
      break;
  }
}

function initSystem(system) {
  centerX = system.centerX;
  centerY = system.centerY;
  roomSize = centerX * 2;

  bodyList.length = 0;
  for (const b of system.orbitalBodies) {
    bodies[b.id] = b;
    bodyList.push(b);
  }
  window.__centerX = centerX;
  window.__centerY = centerY;

  const layers = initRenderer();
  app = getApp();

  initNameplates(app);
  initMenu();

  camera = createCamera(layers.worldContainer, window.innerWidth, window.innerHeight);
  camera.fitSystem(roomSize, roomSize, window.innerWidth, window.innerHeight);

  for (const b of bodyList) {
    if (b.type === "ASTEROID_BELT" || b.type === "RING_SYSTEM") continue;
    addNameplate(b.id, b.name || b.id);
  }
  addNameplate("main-belt", "Cinturão Principal");
  addNameplate("kuiper-belt", "Cinturão de Kuiper");

  setupInput(camera, document.getElementById("game"), onBodyClick);

  document.getElementById("btnCenter").addEventListener("click", () => {
    const fp = fleetPositions[fleetId];
    if (fp) {
      camera.centerOn(fp.x, fp.y);
    }
  });

  document.getElementById("btnLogoff").addEventListener("click", () => {
    try { localStorage.removeItem(SESSION_KEY); } catch (_) {}
    if (ws) {
      try { ws.close(); } catch (_) {}
    }
    location.reload();
  });

  app.ticker.add(() => {
    const now = performance.now();
    const simTime = lastSimulatedTime + (now - lastWallTime);

    for (const fid of Object.keys(fleetPositions)) {
      const extra = fleetExtra[fid];
      if (!extra) continue;
      let ex, ey;
      if (extra.state === "TRAVEL") {
        const mov = currentMovements.find(m => m.fleetId === fid);
        if (mov) {
          const progress = Math.min(
            (simTime - mov.departureTime) / (mov.arrivalTime - mov.departureTime), 1
          );
          const cp = bezierControlPoint(mov.originX, mov.originY, mov.destX, mov.destY, centerX, centerY);
          const pt = bezierPoint(mov.originX, mov.originY, cp.x, cp.y, mov.destX, mov.destY, progress);
          ex = pt.x; ey = pt.y;
        }
      } else if (extra.state === "ORBIT") {
        if (extra.orbitX != null && extra.orbitY != null) {
          ex = extra.orbitX;
          ey = extra.orbitY;
        } else if (extra.orbitRadius != null) {
          const planetPos = currentPositions[extra.locationId];
          if (planetPos) {
            const angle = extra.orbitPhase + (simTime / extra.orbitPeriod) * Math.PI * 2;
            ex = planetPos.x + Math.cos(angle) * extra.orbitRadius;
            ey = planetPos.y + Math.sin(angle) * extra.orbitRadius;
          }
        }
      }
      if (ex != null) setFleetTarget(fid, ex, ey);
    }

    if (beltParticlesInitialized) {
      updateBeltAnimations(camera.state.scale, centerX, centerY);

      if (ringContainer) {
        const saturnPos = currentPositions["saturn"];
        if (saturnPos) {
          ringContainer.x = saturnPos.x;
          ringContainer.y = saturnPos.y;
        }
      }

      updateAllNameplates(bodies, currentPositions, camera);
    }

    camera.lerpToTarget();
    lerpFleetVisuals();
  });

  redrawAll(bodyList, currentPositions, currentMovements, centerX, centerY);
}

function applyStateUpdate(payload) {
  lastSimulatedTime = payload.simulatedTime;
  lastWallTime = performance.now();

  for (const [id, pos] of Object.entries(payload.orbitalBodies)) {
    currentPositions[id] = pos;
  }

  fleetPositions = {};
  for (const [fid, fdata] of Object.entries(payload.fleets)) {
    fleetPositions[fid] = fdata;
    setFleetTarget(fid, fdata.x, fdata.y);
    fleetExtra[fid] = {
      state: fdata.state,
      locationId: fdata.locationId,
      orbitRadius: fdata.orbitRadius,
      orbitPeriod: fdata.orbitPeriod,
      orbitPhase: fdata.orbitPhase,
      orbitX: fdata.orbitX,
      orbitY: fdata.orbitY,
    };
  }
  currentMovements = payload.movements || [];

  if (!beltParticlesInitialized && app) {
    const layers = getLayers();
    const mainBelt = bodies["main-belt"];
    const kuiperBelt = bodies["kuiper-belt"];

    if (mainBelt) {
      createBeltParticles(layers.ringLayer, mainBelt, centerX, centerY);
    }
    if (kuiperBelt) {
      createBeltParticles(layers.ringLayer, kuiperBelt, centerX, centerY);
    }

    const saturn = bodies["saturn"];
    const saturnRing = bodies["saturn-rings"];
    if (saturn && saturnRing) {
      const pos = currentPositions["saturn"];
      if (pos) {
        ringContainer = new PIXI.Container();
        ringContainer.x = pos.x;
        ringContainer.y = pos.y;
        layers.ringLayer.addChild(ringContainer);
        createRingParticles(ringContainer, saturnRing, 0, 0);
      }
    }

    beltParticlesInitialized = true;
  }

  if (app) {
    redrawAll(bodyList, currentPositions, currentMovements, centerX, centerY);
  }
}

let selectedBody = null;

function onBodyClick(screenX, screenY, worldX, worldY, hitBody) {
  if (!hitBody) return;
  if (hitBody.type === "RING_SYSTEM") return;

  selectedBody = hitBody;
  const items = [];
  const fleetState = fleetPositions[fleetId] ? fleetPositions[fleetId].state : null;
  const atDest = fleetState === "ORBIT" && fleetPositions[fleetId].locationId === hitBody.id;

  if (!atDest) {
    items.push({
      label: "Viajar para órbita",
      onClick: () => {
        sendMove(hitBody.id, worldX, worldY);
      },
    });
  }

  if (atDest) {
    if (hitBody.type === "ASTEROID_BELT") {
      items.push({ label: "Iniciar mineração (futuro)", disabled: true });
    } else if (hitBody.type === "PLANET" && hitBody.planetType === "SOLID") {
      items.push({ label: "Minerar planeta (futuro)", disabled: true });
    } else if (hitBody.type === "PLANET" && hitBody.planetType === "GAS") {
      const hasRings = bodyList.some(
        (b) => b.type === "RING_SYSTEM" && b.parentId === hitBody.id
      );
      if (hasRings) {
        items.push({ label: "Minerar asteroides (futuro)", disabled: true });
      }
    }
  }

  items.push({ label: "Cancelar", onClick: () => {} });
  showMenu(screenX, screenY, items);
}

function sendMove(bodyId, clickX, clickY) {
  const dest = bodies[bodyId];
  const payload = {
    destination: { type: "ORBITAL_BODY", bodyId },
  };

  if (dest.type === "ASTEROID_BELT") {
    payload.arrivalPosition = { x: clickX, y: clickY };
  }

  ws.send(
    JSON.stringify({
      type: "COMMAND",
      action: "MOVE_FLEET",
      payload,
    })
  );
}

function initLogin() {
  const planets = [
    { id: "mercury", name: "Mercúrio" },
    { id: "venus", name: "Vênus" },
    { id: "earth", name: "Terra" },
    { id: "mars", name: "Marte" },
    { id: "jupiter", name: "Júpiter" },
    { id: "saturn", name: "Saturno" },
    { id: "uranus", name: "Urano" },
    { id: "neptune", name: "Netuno" },
  ];
  loginSelect.innerHTML = planets
    .map((p) => `<option value="${p.id}">${p.name}</option>`)
    .join("");

  loginBtn.disabled = false;
  loginBtn.textContent = "Iniciar Jornada";

  loginBtn.addEventListener("click", () => {
    const chosen = loginSelect.value;
    loginBtn.disabled = true;
    loginBtn.textContent = "Conectando...";
    const sessionId = getOrCreateSessionId();
    connect(sessionId, chosen);
  });
}

try {
  const existingSessionId = localStorage.getItem(SESSION_KEY);
  if (existingSessionId) {
    loginTitle.textContent = "Reconectando...";
    loginSelect.style.display = "none";
    loginLabel.style.display = "none";
    loginHint.textContent = "Retomando sessão anterior...";
    loginBtn.disabled = true;
    loginBtn.textContent = "Conectando...";
    connect(existingSessionId, null);
  } else {
    initLogin();
  }
} catch (_) {
  initLogin();
}
