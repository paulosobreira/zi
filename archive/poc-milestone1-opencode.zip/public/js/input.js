const ASTEROID_BELTS = new Set(["main-belt", "kuiper-belt"]);

export function setupInput(camera, gameEl, onBodyClick) {
  let isPanning = false;
  let lastX = 0;
  let lastY = 0;

  gameEl.addEventListener("wheel", (e) => {
    e.preventDefault();
    const w = camera.screenToWorld(e.clientX, e.clientY);
    camera.zoomAt(
      e.deltaY < 0 ? 1 : -1,
      w.x,
      w.y,
      window.innerWidth,
      window.innerHeight
    );
  });

  gameEl.addEventListener("mousedown", (e) => {
    if (e.button === 1 || e.button === 2 || e.ctrlKey) {
      isPanning = true;
      lastX = e.clientX;
      lastY = e.clientY;
      e.preventDefault();
    }
  });

  window.addEventListener("mousemove", (e) => {
    if (isPanning) {
      camera.pan(e.clientX - lastX, e.clientY - lastY);
      lastX = e.clientX;
      lastY = e.clientY;
    }
  });

  window.addEventListener("mouseup", (e) => {
    if (e.button === 1 || e.button === 2 || e.ctrlKey) {
      isPanning = false;
    }
  });

  gameEl.addEventListener("contextmenu", (e) => e.preventDefault());

  gameEl.addEventListener("click", (e) => {
    if (isPanning) return;
    if (e.button !== 0) return;

    const w = camera.screenToWorld(e.clientX, e.clientY);
    const hit = detectHit(
      w.x,
      w.y,
      window.__bodies,
      window.__currentPositions,
      window.__centerX,
      window.__centerY
    );
    onBodyClick(e.clientX, e.clientY, w.x, w.y, hit);
  });
}

function detectHit(wx, wy, bodies, positions, cx, cy) {
  if (!bodies || !positions) return null;

  const dist = Math.sqrt((wx - cx) ** 2 + (wy - cy) ** 2);
  let best = null;
  let bestDist = Infinity;

  for (const body of bodies) {
    if (body.type === "RING_SYSTEM") continue;
    const pos = positions[body.id];
    if (!pos) continue;

    if (body.type === "ASTEROID_BELT") {
      if (dist >= body.beltInnerRadius && dist <= body.beltOuterRadius) {
        const d = Math.abs(dist - (body.beltInnerRadius + body.beltOuterRadius) / 2);
        if (d < bestDist) {
          bestDist = d;
          best = body;
        }
      }
    } else {
      const dx = wx - pos.x;
      const dy = wy - pos.y;
      const d = Math.sqrt(dx * dx + dy * dy);
      const hitRadius = body.type === "STAR" ? body.size + 5 : body.size + 15;
      if (d <= hitRadius && d < bestDist) {
        bestDist = d;
        best = body;
      }
    }
  }

  return best;
}
