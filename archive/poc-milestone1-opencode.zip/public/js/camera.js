export function createCamera(container, screenWidth, screenHeight) {
  const state = {
    x: 0,
    y: 0,
    scale: 1,
    minScale: 0.1,
    maxScale: 8,
    targetX: 0,
    targetY: 0,
  };

  container.x = 0;
  container.y = 0;
  container.scale.set(1);

  function apply() {
    container.x = state.x;
    container.y = state.y;
    container.scale.set(state.scale);
  }

  function pan(dx, dy) {
    state.x += dx;
    state.y += dy;
    state.targetX = state.x;
    state.targetY = state.y;
    apply();
  }

  function zoomAt(step, worldX, worldY, _screenW, _screenH) {
    const oldScale = state.scale;
    const factor = 1 + 0.1 * step;
    const newScale = Math.max(state.minScale, Math.min(state.maxScale, oldScale * factor));
    if (newScale === oldScale) return;

    state.x = state.x + worldX * (oldScale - newScale);
    state.y = state.y + worldY * (oldScale - newScale);
    state.scale = newScale;
    state.targetX = state.x;
    state.targetY = state.y;
    apply();
  }

  function worldToScreen(wx, wy) {
    return {
      x: wx * state.scale + state.x,
      y: wy * state.scale + state.y,
    };
  }

  function screenToWorld(sx, sy) {
    return {
      x: (sx - state.x) / state.scale,
      y: (sy - state.y) / state.scale,
    };
  }

  function centerOn(wx, wy) {
    state.targetX = -wx * state.scale + window.innerWidth / 2;
    state.targetY = -wy * state.scale + window.innerHeight / 2;
  }

  function lerpToTarget() {
    state.x += (state.targetX - state.x) * 0.15;
    state.y += (state.targetY - state.y) * 0.15;
    apply();
  }

  function setScale(s) {
    state.scale = Math.max(state.minScale, Math.min(state.maxScale, s));
    apply();
  }

  function fitSystem(worldWidth, worldHeight, screenW, screenH) {
    const sx = screenW / worldWidth;
    const sy = screenH / worldHeight;
    const s = Math.min(sx, sy) * 0.85;
    state.scale = Math.max(state.minScale, Math.min(state.maxScale, s));
    state.x = (screenW - worldWidth * state.scale) / 2;
    state.y = (screenH - worldHeight * state.scale) / 2;
    state.targetX = state.x;
    state.targetY = state.y;
    apply();
  }

  return {
    state,
    pan,
    zoomAt,
    worldToScreen,
    screenToWorld,
    centerOn,
    lerpToTarget,
    setScale,
    fitSystem,
    apply,
  };
}
