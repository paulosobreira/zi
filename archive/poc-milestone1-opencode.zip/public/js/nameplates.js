import * as PIXI from "/js/pixi.mjs";

let nameplateLayer = null;
const labels = {};

export function initNameplates(app) {
  nameplateLayer = new PIXI.Container();
  app.stage.addChild(nameplateLayer);
}

export function addNameplate(id, text) {
  const txt = new PIXI.Text(text, {
    fontFamily: "monospace",
    fontSize: 10,
    fill: "#CCCCCC",
    stroke: "#000000",
    strokeThickness: 2,
  });
  txt.anchor.set(0.5, 0);
  labels[id] = txt;
  nameplateLayer.addChild(txt);
}

export function updateNameplate(id, worldX, worldY, bodySize, cam) {
  const txt = labels[id];
  if (!txt) return;
  const s = cam.worldToScreen(worldX, worldY);
  txt.x = s.x;
  txt.y = s.y + bodySize * cam.state.scale + 4;
}

export function updateAllNameplates(bodies, positions, cam) {
  for (const id of Object.keys(labels)) {
    const body = bodies[id];
    if (!body) continue;
    const pos = positions[id];
    if (!pos) continue;
    if (body.type === "ASTEROID_BELT") {
      const radius = (body.beltInnerRadius + body.beltOuterRadius) / 2;
      const labelX = pos.x + radius;
      const labelY = pos.y;
      updateNameplate(id, labelX, labelY, 6, cam);
    } else {
      updateNameplate(id, pos.x, pos.y, body.size || 6, cam);
    }
  }
}
