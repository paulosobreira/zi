let menuEl;
let justShown = false;

export function initMenu() {
  menuEl = document.getElementById("contextMenu");
  document.addEventListener("click", () => {
    if (justShown) {
      justShown = false;
      return;
    }
    hideMenu();
  });
}

export function showMenu(x, y, items) {
  justShown = true;
  menuEl.innerHTML = "";
  menuEl.style.display = "block";
  menuEl.style.left = x + "px";
  menuEl.style.top = y + "px";

  for (const item of items) {
    const div = document.createElement("div");
    div.className = "item" + (item.disabled ? " disabled" : "");
    div.textContent = item.label;
    if (!item.disabled && item.onClick) {
      div.addEventListener("click", (e) => {
        e.stopPropagation();
        hideMenu();
        item.onClick();
      });
    }
    menuEl.appendChild(div);
  }

  const rect = menuEl.getBoundingClientRect();
  if (rect.right > window.innerWidth) {
    menuEl.style.left = window.innerWidth - rect.width - 10 + "px";
  }
  if (rect.bottom > window.innerHeight) {
    menuEl.style.top = window.innerHeight - rect.height - 10 + "px";
  }
}

export function hideMenu() {
  menuEl.style.display = "none";
  menuEl.innerHTML = "";
}
