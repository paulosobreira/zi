import * as PIXI from "/js/pixi.mjs";

const ANGULAR_SPEED = 0.00005;
const DOT_THRESHOLD = 1.0;
const ARCADETHRESHOLD = 5.0;

const beltSystems = [];

function generateGrainDots() {
  const dots = [];
  const count = 8 + Math.floor(Math.random() * 8);
  for (let i = 0; i < count; i++) {
    dots.push({
      ox: (Math.random() - 0.5) * 4,
      oy: (Math.random() - 0.5) * 4,
      size: 0.2 + Math.random() * 0.6,
      alpha: 0.3 + Math.random() * 0.7,
    });
  }
  return dots;
}

function generateAsteroidVerts() {
  const verts = [];
  const count = 6 + Math.floor(Math.random() * 4);
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2 - Math.PI / count + (Math.random() * Math.PI * 2) / count;
    const r = 3 + Math.random() * 5;
    verts.push(Math.cos(a) * r, Math.sin(a) * r);
  }
  return verts;
}

function drawPixelRect(g, size, color, alpha) {
  g.beginFill(color, alpha);
  g.drawRect(-size / 2, -size / 2, size, size);
  g.endFill();
}

function drawParticle(g, mode, alpha, grainDots, asteroidVerts, cameraScale) {
  g.clear();
  if (mode === "dot") {
    const px = Math.max(1, 1.5 / cameraScale);
    drawPixelRect(g, px, 0x8b7355, 1);
  } else if (mode === "pixel") {
    const numDots = 2 + Math.floor((cameraScale - DOT_THRESHOLD) * 3);
    const show = Math.min(numDots, grainDots.length);
    for (let i = 0; i < show; i++) {
      const d = grainDots[i];
      drawPixelRect(g, d.size, 0x8b7355, alpha * d.alpha);
    }
  } else {
    g.lineStyle(0.6, 0x8b7355, alpha);
    g.drawPolygon(asteroidVerts);
  }
}

function getMode(cameraScale) {
  if (cameraScale < DOT_THRESHOLD) return "dot";
  if (cameraScale < ARCADETHRESHOLD) return "pixel";
  return "arcade";
}

export function createBeltParticles(container, body, cx, cy) {
  const count = body.id === "main-belt" ? 200 : 400;
  const particles = [];

  for (let i = 0; i < count; i++) {
    const angle = Math.random() * 2 * Math.PI;
    const radius =
      body.beltInnerRadius +
      Math.random() * (body.beltOuterRadius - body.beltInnerRadius);
    const x = cx + Math.cos(angle) * radius;
    const y = cy + Math.sin(angle) * radius;
    const alpha = 0.3 + Math.random() * 0.7;

    const grainDots = generateGrainDots();
    const asteroidVerts = generateAsteroidVerts();
    const dir = Math.random() * 2 * Math.PI;
    const speed = 0.01 + Math.random() * 0.04;

    const g = new PIXI.Graphics();
    drawParticle(g, "dot", alpha, grainDots, asteroidVerts, 1);
    g.x = x;
    g.y = y;

    container.addChild(g);
    particles.push({
      graphic: g, angle, radius, alpha,
      grainDots, asteroidVerts, lastMode: "dot",
      asteroidRotation: Math.random() * Math.PI * 2,
      rotSpeed: (Math.random() - 0.5) * 0.003,
      vx: Math.cos(dir) * speed,
      vy: Math.sin(dir) * speed,
      body, cx, cy,
    });
  }

  beltSystems.push({ particles, cx, cy });
  return particles;
}

export function createRingParticles(container, body, cx, cy) {
  const bandCount = 14;
  const bandStart = 1.14;
  const bandEnd = 2.23;
  const bandThick = 0.05;
  const step = (bandEnd - bandStart) / (bandCount - 1);
  const bands = [];
  for (let i = 0; i < bandCount; i++) {
    const t = i / (bandCount - 1);
    const mid = bandStart + step * i;
    const ecc = 0.15 + Math.abs(t - 0.5) * 0.70;
    bands.push({ inner: mid, outer: mid + bandThick, ecc });
  }
  const particlesPerBand = 160;
  const particles = [];

  for (const band of bands) {
    const bandInner = body.size * band.inner;
    const bandOuter = body.size * band.outer;
    const bScale = Math.sqrt(1 - band.ecc * band.ecc);
    for (let i = 0; i < particlesPerBand; i++) {
      const angle = Math.random() * 2 * Math.PI;
      const radius = bandInner + Math.random() * (bandOuter - bandInner);
      const alpha = 0.4 + Math.random() * 0.6;
      const size = 0.3 + Math.random() * 0.3;
      const a = radius;
      const b = radius * bScale;

      const g = new PIXI.Graphics();
      drawPixelRect(g, size, 0xc8b896, alpha);
      g.x = Math.cos(angle) * a;
      g.y = Math.sin(angle) * b;

      container.addChild(g);
      particles.push({ graphic: g, angle, radius });
    }
  }

  return particles;
}

export function updateBeltAnimations(cameraScale, cx, cy) {
  const animating = cameraScale >= DOT_THRESHOLD;
  const mode = getMode(cameraScale);

  for (const belt of beltSystems) {
    for (const p of belt.particles) {
      if (p.lastMode !== mode) {
        drawParticle(p.graphic, mode, p.alpha, p.grainDots, p.asteroidVerts, cameraScale);
        p.lastMode = mode;
      }

      if (mode === "arcade") {
        p.graphic.rotation += p.rotSpeed;
        p.graphic.x += p.vx;
        p.graphic.y += p.vy;

        const dx = p.graphic.x - p.cx;
        const dy = p.graphic.y - p.cy;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const outer = p.body.beltOuterRadius;
        const inner = p.body.beltInnerRadius;

        if (dist > outer) {
          const clamp = inner + Math.random() * (outer - inner) * 0.3;
          p.graphic.x = p.cx + (dx / dist) * clamp;
          p.graphic.y = p.cy + (dy / dist) * clamp;
        } else if (dist < inner) {
          const clamp = inner + Math.random() * (outer - inner) * 0.7;
          p.graphic.x = p.cx + (dx / dist) * clamp;
          p.graphic.y = p.cy + (dy / dist) * clamp;
        }
      } else {
        p.graphic.rotation = 0;
        if (animating) {
          p.angle += ANGULAR_SPEED * (1 / 60);
          p.graphic.x = belt.cx + Math.cos(p.angle) * p.radius;
          p.graphic.y = belt.cy + Math.sin(p.angle) * p.radius;
        }
      }
    }
  }
}

export function updateRingVisibility() {}
