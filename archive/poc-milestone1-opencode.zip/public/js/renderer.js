import * as PIXI from "/js/pixi.mjs";

let app;
let worldContainer;
let orbitLayer;
let bodyLayer;
let fleetLayer;
let ringLayer;

const fleetGraphics = {};
const fleetTargets = {};
const fleetVisuals = {};

export function initRenderer() {
  app = new PIXI.Application({
    resizeTo: window,
    backgroundColor: 0x0a0a1a,
    antialias: true,
  });

  const gameEl = document.getElementById("game");
  const canvas = app.view || app.canvas || document.querySelector("#game canvas");
  gameEl.appendChild(canvas);

  worldContainer = new PIXI.Container();
  app.stage.addChild(worldContainer);

  orbitLayer = new PIXI.Container();
  bodyLayer = new PIXI.Container();
  ringLayer = new PIXI.Container();
  fleetLayer = new PIXI.Container();

  worldContainer.addChild(orbitLayer);
  worldContainer.addChild(bodyLayer);
  worldContainer.addChild(ringLayer);
  worldContainer.addChild(fleetLayer);

  return { app, worldContainer, orbitLayer, bodyLayer, fleetLayer, ringLayer };
}

export function getApp() {
  return app;
}

export function getLayers() {
  return { orbitLayer, bodyLayer, fleetLayer, ringLayer };
}

function drawOrbit(cx, cy, a, e) {
  if (a === 0) return;
  const b = a * Math.sqrt(1 - e * e);
  const g = new PIXI.Graphics();
  g.lineStyle(1.5, 0x2a2a4a, 0.5);
  g.drawEllipse(cx - a * e, cy, a, b);
  orbitLayer.addChild(g);
}

function createBodyGraphic(body, x, y) {
  const g = new PIXI.Graphics();
  const color = parseInt(body.color.slice(1), 16);

  if (body.type === "STAR") {
    g.beginFill(color, 1);
    g.drawCircle(0, 0, body.size);
    g.endFill();
  } else if (body.type === "PLANET") {
    g.beginFill(color, 1);
    g.drawCircle(0, 0, body.size);
    g.endFill();
  }

  g.x = x;
  g.y = y;
  bodyLayer.addChild(g);
  return g;
}

function drawTrajectory(ox, oy, cp, dx, dy) {
  const g = new PIXI.Graphics();
  g.lineStyle(1, 0x00ff88, 0.5);
  g.moveTo(ox, oy);
  g.quadraticCurveTo(cp.x, cp.y, dx, dy);
  orbitLayer.addChild(g);
}

function bezierControlPoint(ox, oy, dx, dy, cx, cy) {
  const mx = (ox + dx) / 2;
  const my = (oy + dy) / 2;
  const dirX = mx - cx;
  const dirY = my - cy;
  const len = Math.sqrt(dirX * dirX + dirY * dirY) || 1;
  const dist = Math.sqrt((ox - cx) ** 2 + (oy - cy) ** 2);
  const push = dist * 0.8;
  return {
    x: mx + (dirX / len) * push,
    y: my + (dirY / len) * push,
  };
}

function bezierPoint(p0x, p0y, p1x, p1y, p2x, p2y, t) {
  const u = 1 - t;
  return {
    x: u * u * p0x + 2 * u * t * p1x + t * t * p2x,
    y: u * u * p0y + 2 * u * t * p1y + t * t * p2y,
  };
}

export { bezierControlPoint, bezierPoint };

export function setFleetTarget(fid, x, y) {
  fleetTargets[fid] = { x, y };
  if (!fleetVisuals[fid]) {
    fleetVisuals[fid] = { x, y };
  }
  if (!fleetGraphics[fid]) {
    const g = new PIXI.Graphics();
    g.beginFill(0x00ff88, 1);
    g.moveTo(0, -3);
    g.lineTo(2.6, 2);
    g.lineTo(-2.6, 2);
    g.closePath();
    g.endFill();
    g.x = x;
    g.y = y;
    fleetLayer.addChild(g);
    fleetGraphics[fid] = g;
  }
}

export function lerpFleetVisuals() {
  for (const fid of Object.keys(fleetTargets)) {
    const target = fleetTargets[fid];
    const visual = fleetVisuals[fid];
    const g = fleetGraphics[fid];
    if (!target || !visual || !g) continue;
    visual.x += (target.x - visual.x) * 0.15;
    visual.y += (target.y - visual.y) * 0.15;
    g.x = visual.x;
    g.y = visual.y;
  }
}

export function clearFleetTargets() {
  for (const fid of Object.keys(fleetGraphics)) {
    fleetGraphics[fid].destroy();
    delete fleetGraphics[fid];
  }
  for (const fid of Object.keys(fleetTargets)) {
    delete fleetTargets[fid];
  }
  for (const fid of Object.keys(fleetVisuals)) {
    delete fleetVisuals[fid];
  }
}

export function redrawAll(bodies, positions, movements, centerX, centerY) {
  orbitLayer.removeChildren();
  bodyLayer.removeChildren();

  for (const body of bodies) {
    if (body.type === "ASTEROID_BELT" || body.type === "RING_SYSTEM") continue;
    if (body.semiMajorAxis > 0) {
      drawOrbit(centerX, centerY, body.semiMajorAxis, body.eccentricity);
    }
  }

  for (const body of bodies) {
    if (body.type === "ASTEROID_BELT") {
      const color = parseInt(body.color.slice(1), 16);
      const midRadius = (body.beltInnerRadius + body.beltOuterRadius) / 2;
      const g = new PIXI.Graphics();
      g.lineStyle(1.5, color, 0.3);
      g.drawCircle(centerX, centerY, midRadius);
      orbitLayer.addChild(g);
      continue;
    }
    if (body.type === "RING_SYSTEM") continue;
    const pos = positions[body.id];
    if (!pos) continue;
    createBodyGraphic(body, pos.x, pos.y);
  }

  for (const mov of movements) {
    const cp = bezierControlPoint(mov.originX, mov.originY, mov.destX, mov.destY, centerX, centerY);
    drawTrajectory(mov.originX, mov.originY, cp, mov.destX, mov.destY);
  }
}
