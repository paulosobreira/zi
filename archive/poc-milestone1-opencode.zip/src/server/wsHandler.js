let nextPlayerId = 1;

function handleMessage(ws, sim, raw) {
  let msg;
  try {
    msg = JSON.parse(raw);
  } catch (_) {
    send(ws, { type: "ERROR", code: "INVALID_ACTION", message: "JSON inválido" });
    return;
  }

  if (msg.type !== "COMMAND") {
    send(ws, { type: "ERROR", code: "INVALID_ACTION", message: "Esperado COMMAND" });
    return;
  }

  const action = msg.action;
  const payload = msg.payload || {};

  if (action === "HELLO") {
    const sessionId = payload.sessionId;
    const startingBody = payload.startingBody;

    let playerId;

    if (sessionId) {
      const existing = sim.getOrCreateSession(sessionId);
      if (existing) {
        playerId = existing.playerId;
      }
    }

    if (!playerId) {
      playerId = "player-" + nextPlayerId++;
      sim.addPlayerWithStartingBody(playerId, startingBody);
      if (sessionId) {
        sim.createSession(sessionId, playerId);
      }
    }

    send(ws, { type: "WELCOME", playerId });

    const systemData = sim.getSystemData();
    send(ws, { type: "SYSTEM_DATA", payload: { system: systemData } });

    const fleet = sim.fleets[playerId];
    send(ws, {
      type: "FLEET_DATA",
      payload: {
        fleetId: playerId,
        location: {
          type: "ORBITAL_BODY",
          bodyId: fleet.locationId,
          bodyType: sim.getBody(fleet.locationId).type,
        },
      },
    });

    ws.playerId = playerId;
    sim.addClient(ws);
    return;
  }

  if (action === "PONG") {
    return;
  }

  if (action === "MOVE_FLEET") {
    const dest = payload.destination;
    if (!dest || dest.type !== "ORBITAL_BODY" || !dest.bodyId) {
      send(ws, { type: "ERROR", code: "INVALID_DESTINATION", message: "Destino inválido" });
      return;
    }

    const body = sim.getBody(dest.bodyId);
    if (!body) {
      send(ws, { type: "ERROR", code: "INVALID_DESTINATION", message: "Corpo não encontrado" });
      return;
    }

    const arrivalPos = payload.arrivalPosition || {};
    const arrivalX = arrivalPos.x != null ? arrivalPos.x : sim.centerX;
    const arrivalY = arrivalPos.y != null ? arrivalPos.y : sim.centerY;

    const result = sim.handleMoveFleet(ws.playerId, dest.bodyId, arrivalX, arrivalY);
    if (result.error) {
      send(ws, { type: "ERROR", code: result.error, message: result.error });
      return;
    }

    send(ws, {
      type: "MOVE_STARTED",
      payload: { fleetId: result.fleetId, arrivalSimulatedTime: result.arrivalTime },
    });
    return;
  }

  send(ws, { type: "ERROR", code: "INVALID_ACTION", message: "Ação desconhecida: " + action });
}

function send(ws, data) {
  try {
    ws.send(JSON.stringify(data));
  } catch (_) {}
}

module.exports = { handleMessage };
