const http = require("http");
const { WebSocketServer } = require("ws");
const Simulation = require("./simulation");
const { handleMessage } = require("./wsHandler");

const PORT = 3001;
const sim = new Simulation();

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ status: "zeus-interestelar server running" }));
});

const wss = new WebSocketServer({ server });

wss.on("connection", (ws) => {
  ws.on("message", (raw) => handleMessage(ws, sim, raw));
  ws.on("close", () => sim.removeClient(ws));
  ws.on("error", () => sim.removeClient(ws));
});

setInterval(() => {
  sim.tick();
}, 1000);

server.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
  console.log(`Sala: ${sim.centerX * 2} x ${sim.centerY * 2} pixels`);
});
