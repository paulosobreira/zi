const { calculatePosition, bezierPoint, calcBezierControlPoint } = require("./orbitalPhysics");
const { SOLAR_SYSTEM_BODIES, CENTER_X, CENTER_Y } = require("./solarSystemData");

class Simulation {
  constructor() {
    this.simulatedTime = 0;
    this.tickCount = 0;
    this.players = {};
    this.fleets = {};
    this.movements = {};
    this.bodies = SOLAR_SYSTEM_BODIES.map((b) => ({ ...b }));
    this.centerX = CENTER_X;
    this.centerY = CENTER_Y;
    this.clients = [];
    this.sessions = {};
  }

  addClient(ws) {
    this.clients.push(ws);
  }

  removeClient(ws) {
    this.clients = this.clients.filter((c) => c !== ws);
  }

  getBody(id) {
    return this.bodies.find((b) => b.id === id);
  }

  getBeltForRadius(dist) {
    for (const b of this.bodies) {
      if (
        b.type === "ASTEROID_BELT" &&
        dist >= b.beltInnerRadius &&
        dist <= b.beltOuterRadius
      ) {
        return b;
      }
    }
    return null;
  }

  getCurrentPositions() {
    const positions = {};
    for (const body of this.bodies) {
      positions[body.id] = calculatePosition(
        body,
        this.simulatedTime,
        this.centerX,
        this.centerY
      );
    }

    for (const fleetId of Object.keys(this.fleets)) {
      const fleet = this.fleets[fleetId];
      let fx, fy;

      if (fleet.state === "TRAVEL") {
        const mov = this.movements[fleetId];
        if (mov) {
          const progress = Math.min(
            (this.simulatedTime - mov.departureTime) /
              (mov.arrivalTime - mov.departureTime),
            1
          );
          const cp = calcBezierControlPoint(
            mov.originX, mov.originY,
            mov.destX, mov.destY,
            this.centerX, this.centerY
          );
          const pt = bezierPoint(
            mov.originX, mov.originY,
            cp.x, cp.y,
            mov.destX, mov.destY,
            progress
          );
          fx = pt.x;
          fy = pt.y;
        } else {
          fx = this.centerX;
          fy = this.centerY;
        }
      } else if (fleet.state === "ORBIT") {
        const body = this.getBody(fleet.locationId);
        if (body) {
          if (body.type === "ASTEROID_BELT" && fleet.orbitX != null && fleet.orbitY != null) {
            fx = fleet.orbitX;
            fy = fleet.orbitY;
          } else {
            const planetPos = calculatePosition(body, this.simulatedTime, this.centerX, this.centerY);
            const angle = fleet.orbitPhase + (this.simulatedTime / fleet.orbitPeriod) * Math.PI * 2;
            fx = planetPos.x + Math.cos(angle) * fleet.orbitRadius;
            fy = planetPos.y + Math.sin(angle) * fleet.orbitRadius;
          }
        } else {
          fx = this.centerX;
          fy = this.centerY;
        }
      } else {
        fx = this.centerX;
        fy = this.centerY;
      }

      positions["fleet-" + fleetId] = { x: fx, y: fy };
    }

    return positions;
  }

  handleMoveFleet(playerId, bodyId, arrivalX, arrivalY) {
    const fleet = this.fleets[playerId];
    if (!fleet) return { error: "FLEET_NOT_FOUND" };
    if (fleet.state === "TRAVEL") return { error: "FLEET_BUSY" };

    const dest = this.getBody(bodyId);
    if (!dest) return { error: "INVALID_DESTINATION" };

    const originPos = this.getCurrentPositions();
    const fleetPos = originPos["fleet-" + playerId] ||
      { x: this.centerX, y: this.centerY };

    let destX, destY, orbitRadius, orbitPeriod;

    if (dest.type === "ASTEROID_BELT") {
      const angle = Math.atan2(arrivalY - this.centerY, arrivalX - this.centerX);
      const midRadius = (dest.beltInnerRadius + dest.beltOuterRadius) / 2;
      destX = this.centerX + Math.cos(angle) * midRadius;
      destY = this.centerY + Math.sin(angle) * midRadius;
      orbitRadius = midRadius;
      orbitPeriod = dest.id === "main-belt" ? 687 : 60190;
    } else {
      const destPos = calculatePosition(dest, this.simulatedTime, this.centerX, this.centerY);
      destX = destPos.x;
      destY = destPos.y;
      orbitRadius = dest.size + 5;
      orbitPeriod = 15000;
    }

    const dx = destX - fleetPos.x;
    const dy = destY - fleetPos.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const fleetSpeed = 6;
    const travelTime = (distance / fleetSpeed) * 1000;

    const departureTime = this.simulatedTime;
    const arrivalTime = this.simulatedTime + travelTime;

    this.movements[playerId] = {
      fleetId: playerId,
      originId: fleet.locationId,
      destinationId: bodyId,
      originX: fleetPos.x,
      originY: fleetPos.y,
      destX,
      destY,
      departureTime,
      arrivalTime,
    };

    fleet.state = "TRAVEL";
    fleet.orbitRadius = orbitRadius;
    fleet.orbitPeriod = orbitPeriod;
    fleet.orbitPhase = Math.random() * Math.PI * 2;
    fleet.locationId = bodyId;
    if (dest.type === "ASTEROID_BELT") {
      fleet.orbitX = destX;
      fleet.orbitY = destY;
    } else {
      delete fleet.orbitX;
      delete fleet.orbitY;
    }

    return {
      fleetId: playerId,
      arrivalTime,
    };
  }

  tick() {
    this.simulatedTime += 1000;
    this.tickCount++;

    for (const fleetId of Object.keys(this.movements)) {
      const mov = this.movements[fleetId];
      if (this.simulatedTime >= mov.arrivalTime) {
        const fleet = this.fleets[fleetId];
        if (fleet) {
          fleet.state = "ORBIT";
        }
        delete this.movements[fleetId];
      }
    }

    const positions = this.getCurrentPositions();
    const payload = {
      tick: this.tickCount,
      simulatedTime: this.simulatedTime,
      orbitalBodies: {},
      fleets: {},
      movements: [],
    };

    for (const [id, pos] of Object.entries(positions)) {
      if (id.startsWith("fleet-")) {
        const fleetId = id.slice(6);
        const fleet = this.fleets[fleetId];
        if (fleet) {
          payload.fleets[fleetId] = {
            state: fleet.state,
            locationId: fleet.locationId,
            x: pos.x,
            y: pos.y,
            orbitRadius: fleet.orbitRadius,
            orbitPeriod: fleet.orbitPeriod,
            orbitPhase: fleet.orbitPhase,
            orbitX: fleet.orbitX,
            orbitY: fleet.orbitY,
          };
          if (fleet.state === "TRAVEL" && this.movements[fleetId]) {
            payload.movements.push(this.movements[fleetId]);
          }
        }
      } else {
        payload.orbitalBodies[id] = pos;
      }
    }

    const msg = JSON.stringify({ type: "STATE_UPDATE", payload });
    for (const ws of this.clients) {
      try {
        ws.send(msg);
      } catch (_) {}
    }
  }

  getSystemData() {
    return {
      id: "sol",
      centerX: this.centerX,
      centerY: this.centerY,
      orbitalBodies: this.bodies.map((b) => {
        const o = { id: b.id, type: b.type, color: b.color };
        if (b.type === "PLANET") {
          o.planetType = b.planetType;
          o.semiMajorAxis = b.semiMajorAxis;
          o.eccentricity = b.eccentricity;
          o.orbitalPeriod = b.orbitalPeriod;
          o.orbitalPhase = b.orbitalPhase;
          o.size = b.size;
        } else if (b.type === "STAR") {
          o.size = b.size;
        } else if (b.type === "ASTEROID_BELT") {
          o.beltInnerRadius = b.beltInnerRadius;
          o.beltOuterRadius = b.beltOuterRadius;
        } else if (b.type === "RING_SYSTEM") {
          o.parentId = b.parentId;
          o.size = b.size;
        }
        return o;
      }),
    };
  }

  addPlayer(playerId) {
    return this.addPlayerWithStartingBody(playerId, null);
  }

  addPlayerWithStartingBody(playerId, bodyId) {
    this.players[playerId] = { id: playerId, createdAt: Date.now() };

    let startPlanet;
    if (bodyId) {
      const body = this.bodies.find((b) => b.id === bodyId);
      if (body && body.type === "PLANET") startPlanet = body;
    }
    if (!startPlanet) {
      const planets = this.bodies.filter((b) => b.type === "PLANET");
      startPlanet = planets[Math.floor(Math.random() * planets.length)];
    }

    this.fleets[playerId] = {
      id: playerId,
      ownerId: playerId,
      locationType: "ORBITAL_BODY",
      locationId: startPlanet.id,
      state: "ORBIT",
      orbitRadius: startPlanet.size + 5,
      orbitPeriod: 15000,
      orbitPhase: Math.random() * Math.PI * 2,
    };
  }

  getOrCreateSession(sessionId) {
    if (this.sessions[sessionId]) {
      return { playerId: this.sessions[sessionId], isNew: false };
    }
    return null;
  }

  createSession(sessionId, playerId) {
    this.sessions[sessionId] = playerId;
  }
}

module.exports = Simulation;
