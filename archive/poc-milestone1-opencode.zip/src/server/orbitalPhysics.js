function calculatePosition(body, simulatedTime, centerX, centerY) {
  if (body.orbitalPeriod === 0) {
    return { x: centerX, y: centerY };
  }

  const theta =
    ((2 * Math.PI * simulatedTime) / (body.orbitalPeriod * 86400) +
      body.orbitalPhase) %
    (2 * Math.PI);

  const e = body.eccentricity;
  const a = body.semiMajorAxis;
  const r = (a * (1 - e * e)) / (1 + e * Math.cos(theta));

  return {
    x: centerX + r * Math.cos(theta),
    y: centerY + r * Math.sin(theta),
  };
}

function bezierPoint(p0x, p0y, p1x, p1y, p2x, p2y, t) {
  const mt = 1 - t;
  return {
    x: mt * mt * p0x + 2 * mt * t * p1x + t * t * p2x,
    y: mt * mt * p0y + 2 * mt * t * p1y + t * t * p2y,
  };
}

function calcBezierControlPoint(ox, oy, dx, dy, cx, cy) {
  const mx = (ox + dx) / 2;
  const my = (oy + dy) / 2;
  const dirX = mx - cx;
  const dirY = my - cy;
  const len = Math.sqrt(dirX * dirX + dirY * dirY) || 1;
  const dist = Math.sqrt((ox - cx) ** 2 + (oy - cy) ** 2);
  const push = dist * 0.8;
  return {
    x: mx + (dirX / len) * push,
    y: my + (dirY / len) * push,
  };
}

module.exports = { calculatePosition, bezierPoint, calcBezierControlPoint };
