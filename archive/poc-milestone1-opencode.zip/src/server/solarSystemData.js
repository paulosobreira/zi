function seededPhase(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) {
    h = ((h << 5) - h + id.charCodeAt(i)) | 0;
  }
  return (Math.abs(h) % 1000) / 1000 * 2 * Math.PI;
}

const SOLAR_SYSTEM_BODIES = [
  { id: "sun",         name: "Sol",              type: "STAR",         semiMajorAxis: 0,    eccentricity: 0, orbitalPeriod: 0, orbitalPhase: 0, size: 28, color: "#FFD700", planetType: null, beltInnerRadius: 0, beltOuterRadius: 0, parentId: null },
  { id: "mercury",     name: "Mercúrio",          type: "PLANET",      planetType: "SOLID", semiMajorAxis: 57.9,  eccentricity: 0.205, orbitalPeriod: 88,    orbitalPhase: seededPhase("mercury"), size: 5,  color: "#B5B5B5", beltInnerRadius: 0, beltOuterRadius: 0, parentId: null },
  { id: "venus",       name: "Vênus",             type: "PLANET",      planetType: "SOLID", semiMajorAxis: 108.2, eccentricity: 0.007, orbitalPeriod: 225,   orbitalPhase: seededPhase("venus"), size: 8,  color: "#E6B87D", beltInnerRadius: 0, beltOuterRadius: 0, parentId: null },
  { id: "earth",       name: "Terra",             type: "PLANET",      planetType: "SOLID", semiMajorAxis: 149.6, eccentricity: 0.017, orbitalPeriod: 365,   orbitalPhase: seededPhase("earth"), size: 8,  color: "#4B7BE5", beltInnerRadius: 0, beltOuterRadius: 0, parentId: null },
  { id: "mars",        name: "Marte",             type: "PLANET",      planetType: "SOLID", semiMajorAxis: 227.9, eccentricity: 0.093, orbitalPeriod: 687,   orbitalPhase: seededPhase("mars"), size: 6, color: "#E27B58", beltInnerRadius: 0, beltOuterRadius: 0, parentId: null },
  { id: "main-belt",   name: "Cinturão Principal", type: "ASTEROID_BELT", semiMajorAxis: 0, eccentricity: 0, orbitalPeriod: 0, orbitalPhase: 0, size: 0, color: "#8B7355", planetType: null, beltInnerRadius: 300, beltOuterRadius: 500, parentId: null },
  { id: "jupiter",     name: "Júpiter",           type: "PLANET",      planetType: "GAS",    semiMajorAxis: 778.5, eccentricity: 0.049, orbitalPeriod: 4333,  orbitalPhase: seededPhase("jupiter"), size: 12, color: "#D4A574", beltInnerRadius: 0, beltOuterRadius: 0, parentId: null },
  { id: "saturn",      name: "Saturno",           type: "PLANET",      planetType: "GAS",    semiMajorAxis: 1434,  eccentricity: 0.057, orbitalPeriod: 10759, orbitalPhase: seededPhase("saturn"), size: 10, color: "#E8D5A3", beltInnerRadius: 0, beltOuterRadius: 0, parentId: null },
  { id: "saturn-rings",name: "Anéis de Saturno",   type: "RING_SYSTEM", semiMajorAxis: 0,    eccentricity: 0, orbitalPeriod: 0, orbitalPhase: 0, size: 18, color: "#C8B896", planetType: null, beltInnerRadius: 0, beltOuterRadius: 0, parentId: "saturn" },
  { id: "uranus",      name: "Urano",             type: "PLANET",      planetType: "GAS",    semiMajorAxis: 2871,  eccentricity: 0.046, orbitalPeriod: 30687, orbitalPhase: seededPhase("uranus"), size: 8,  color: "#73B1B7", beltInnerRadius: 0, beltOuterRadius: 0, parentId: null },
  { id: "neptune",     name: "Netuno",            type: "PLANET",      planetType: "GAS",    semiMajorAxis: 4495,  eccentricity: 0.010, orbitalPeriod: 60190, orbitalPhase: seededPhase("neptune"), size: 7,  color: "#3E54E8", beltInnerRadius: 0, beltOuterRadius: 0, parentId: null },
  { id: "kuiper-belt", name: "Cinturão de Kuiper", type: "ASTEROID_BELT", semiMajorAxis: 0, eccentricity: 0, orbitalPeriod: 0, orbitalPhase: 0, size: 0, color: "#8B7355", planetType: null, beltInnerRadius: 4500, beltOuterRadius: 7000, parentId: null },
];

function getMaxDist() {
  let max = 0;
  for (const b of SOLAR_SYSTEM_BODIES) {
    if (b.type === "ASTEROID_BELT") {
      if (b.beltOuterRadius > max) max = b.beltOuterRadius;
    } else if (b.type === "STAR" || b.type === "RING_SYSTEM") {
      continue;
    } else {
      const d = b.semiMajorAxis * (1 + b.eccentricity);
      if (d > max) max = d;
    }
  }
  return max;
}

const MARGIN = 0.25;
const MAX_DIST = getMaxDist();
const ROOM_SIZE = Math.ceil((MAX_DIST * (1 + MARGIN)) * 2);
const CENTER_X = Math.round(ROOM_SIZE / 2);
const CENTER_Y = Math.round(ROOM_SIZE / 2);

module.exports = { SOLAR_SYSTEM_BODIES, ROOM_SIZE, CENTER_X, CENTER_Y };
